//get html ui element
let form = document.querySelector('#book-form');

class Book{
    constructor(title, author, isbn){
        this.title= title;
        this.author= author;
        this.isbn= isbn;
    }
}
/*
class UI{
    constructor(){

    }
    addToBooklist(book){
        let list = document.querySelector('#booklist');
        let row = document.querySelector('tr');
        row.innerHTML = `
        <td>${book.title}</td>
        <td>${book.author}</td>
        <td>${book.isbn}</td>
        <td><a href='#' class="delete">X</a></td>`
        console.log(row);
       
    }
}*/

form.addEventListener('submit', addBook);


function addBook(e){
   
    let title = document.querySelector("#title").Value,
    author = document.querySelector("#author").Value,
    isbn = document.querySelector("#isbn").value;

    let book = new Book(title , author, isbn);
    console.log(author);
    console.log(book);
     
   /* let uii = new UI();
    uii.addToBooklist(book);*/
    
    e.preventDefault();
}